// Function to display dish details when an image is clicked
function showDishDetails(dish) {
    const descriptions = {
        pizza_slice: 'New York-style slice with a crispy crust and gooey mozzarella. Price: $3.50.',
        pepperoni: 'Classic pepperoni pizza with a smoky flavor. Price: $4.00.',
        veggie: 'A healthy veggie pizza loaded with fresh toppings. Price: $4.50.',
        sushi_roll: 'Fresh sushi rolls with avocado, cucumber, and tuna. Price: $8.00.',
        ramen: 'Warm, comforting ramen with pork broth and noodles. Price: $9.00.',
        tempura: 'Crispy tempura with shrimp and vegetables. Price: $7.50.',
        cappuccino: 'Rich cappuccino with a frothy top. Price: $4.00.',
        blueberry_muffin: 'Freshly baked blueberry muffin. Price: $2.50.',
        latte: 'Smooth latte with the perfect balance of coffee and milk. Price: $4.50.'
    };

    const descriptionDiv = document.getElementById('dish-description');
    
    // Check if descriptionDiv exists before trying to update its content
    if (descriptionDiv) {
        descriptionDiv.textContent = descriptions[dish];
    } else {
        console.error('Dish description element not found');
    }
}

// Meal plan functionality: add dishes to the meal plan
let totalCost = 0;

// Function to add an item to the meal plan
function addToMealPlan(dish, price) {
    const mealList = document.getElementById('selected-meals');

    // Create a new list item
    const newItem = document.createElement('li');
    newItem.textContent = `${dish} - $${price.toFixed(2)}`;
    
    // Create a "Remove" button for the item
    const removeButton = document.createElement('button');
    removeButton.textContent = "Remove";
    removeButton.style.marginLeft = "10px";
    removeButton.onclick = () => {
        mealList.removeChild(newItem);
        updateTotalCost(-price);
    };

    // Add the remove button to the new list item
    newItem.appendChild(removeButton);
    mealList.appendChild(newItem);

    // Update total cost
    updateTotalCost(price);
}

// Function to update the total cost
function updateTotalCost(amount) {
    totalCost += amount;
    document.getElementById('total-cost').textContent = totalCost.toFixed(2);
}
