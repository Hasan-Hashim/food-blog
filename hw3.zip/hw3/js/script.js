function showDishDetails(dish) {
    const descriptions = {
        pizza_slice: 'New York-style slice with a crispy crust and gooey mozzarella. Price: $3.50.',
        pepperoni: 'Classic pepperoni pizza with a smoky flavor. Price: $4.00.',
        veggie: 'A healthy veggie pizza loaded with fresh toppings. Price: $4.50.',
        sushi_roll: 'Fresh sushi rolls with avocado, cucumber, and tuna. Price: $8.00.',
        ramen: 'Warm, comforting ramen with pork broth and noodles. Price: $9.00.',
        tempura: 'Crispy tempura with shrimp and vegetables. Price: $7.50.',
        cappuccino: 'Rich cappuccino with a frothy top. Price: $4.00.',
        blueberry_muffin: 'Freshly baked blueberry muffin. Price: $2.50.',
        latte: 'Smooth latte with the perfect balance of coffee and milk. Price: $4.50.'
    };

    const descriptionDiv = document.getElementById('dish-description');
    descriptionDiv.textContent = descriptions[dish];
}

let totalCost = 0;

function addToMealPlan(dish, price) {
    const mealList = document.getElementById('selected-meals');
    const newItem = document.createElement('li');
    newItem.textContent = `${dish} - $${price}`;
    mealList.appendChild(newItem);

    totalCost += price;
    document.getElementById('total-cost').textContent = totalCost;
}
